<p align="right"><a href="ppt-pager.zh_CN.md">简体中文</a> · <strong>English</strong></p>

# PPT Pager

PPT Pager turns AI Passport into a local-network presentation remote for a
macOS presenter. Its display shows a compact monochrome live thumbnail of the
Mac's current screen. It works with PowerPoint, Keynote, or a browser slideshow
when that presentation stays in the foreground.

## What it does

- UP goes to the previous slide.
- DOWN goes to the next slide.
- A short OK press raises the Mac's output volume; a long OK press lowers it.
- First-time Wi-Fi setup uses a short-lived, password-protected local access
  point and a page opened in the iPhone browser. It does not require WeChat or
  Bluetooth pairing.
- The display shows the connection state, a six-digit pairing code, battery
  percentage when available, and a 128 × 72 live display preview.

The device has no PSRAM, so the preview is a deliberately compact one-bit image
instead of a video stream. This keeps Wi-Fi, local setup, UI, and
the application within the ESP32-C3's memory budget.

## Set up a presentation

1. Flash the verified merged firmware from offset 0x0. A complete merged flash
   can reset the device's NVS data.
2. When the device shows IPHONE WI-FI SETUP, open **Settings → Wi-Fi** on the
   iPhone and join the `PPTPager-xxxx` network shown after JOIN on the device.
   Its password is shown after AP and is `PPT` plus the current six-digit code.
   In Safari, open `http://192.168.4.1`, choose the presenter's 2.4 GHz Wi-Fi
   from the nearby-network list, enter its password, and submit the form.
   For a hidden network, enter its exact name manually. When the device shows
   LOOKING FOR MAC, rejoin the iPhone to the normal Wi-Fi. The Mac and AI
   Passport must be on that same local network.
3. Read the six digits after PAIR once the device leaves setup and, on the presenting Mac,
   run the following command. Replace 123456 with the code currently shown.

       python3 companion/ppt_pager_companion.py --code 123456

4. Give the application that launches the companion macOS Screen Recording
   permission for the preview and Accessibility permission for slide keys.
   This is ChatGPT when launched from this chat, or the terminal application
   when launched manually. Approve System Events automation if macOS asks.
   Start the slideshow and keep its window focused.
5. Wait for the device to show CONNECTED, then use the three controls.

Double-press UP to erase the stored Wi-Fi credentials and reopen the local
iPhone setup page. This is intentionally separate from the normal UP click.

## If Wi-Fi setup fails

The browser's Connecting page acknowledges the request; it is not confirmation
that the device joined Wi-Fi. On failure, the device retains its setup hotspot
and displays a short message with the Wi-Fi reason code. The web page also
shows the last failure while the phone remains connected to that hotspot.

- `NO WI-FI FOUND 201`: select the exact network name from the scan list.
  The device sees 2.4 GHz networks only; a 5 GHz-only network will not appear.
- `CHECK PASSWORD`: authentication or the key handshake failed. Check the
  password and router security settings; this is not proof of a mistyped password.
- `WI-FI SECURITY`: no network with compatible security was found.
- For other failures, retain the numeric code for diagnosis.

Use Choose Wi-Fi again to return to the form. Selecting a scanned name preserves
its Chinese characters, spaces, and punctuation without retyping. Network names
and passwords are not written to application diagnostic logs.

## Local-network security

The companion accepts only requests carrying the code currently shown on the
device. It listens on the local network and uses UDP discovery plus HTTP; this
is not encrypted transport. Use it only on a trusted LAN and never expose its
port to the public Internet. Restarting AI Passport generates a new pairing
code.

## Development checks

The companion uses only the Python standard library. Its bitmap conversion and
pairing/discovery parser are covered by companion/test_ppt_pager_companion.py.
The firmware protocol parser is covered by tests/test_ppt_protocol.c.
Form decoding and scanned-name HTML escaping are covered by
tests/test_ppt_setup_portal.c.

Hardware acceptance covers: local iPhone setup on a real phone,
Wi-Fi reconnect after restart, discovery through a real LAN, macOS permission
prompts, screenshot rendering, all four commands, and the Wi-Fi reset gesture.
Completed and pending checks are recorded below.

## Validation checkpoint: 2026-11-09

The earlier web-setup build was tested on an iPhone 15 Pro Max. Joining the
device's hotspot and opening/submitting the local form worked. The saved
station configuration was retried after restart, but the device returned to
setup before obtaining an IP address. That build did not log the station's
disconnect reason, so the cause remains unconfirmed.

The following replacement adds network selection and visible disconnect reasons.
It passed the complete validation gate and archive verification, then was
flashed with the user's approval as an application-only update on the confirmed
USB device. The write hash was verified and the startup ELF identity matched:

- Bundle: `build/firmware/6abd236adf7dd69e5e5589b3cf3c66f6f50a461325ef4afc14c852ed2988205b/`
- Full-image SHA-256: `6abd236adf7dd69e5e5589b3cf3c66f6f50a461325ef4afc14c852ed2988205b`
- Matching ELF SHA-256: `99256935180bc0fa9881bb65349435d3b7cac2034a5e3e1c70370c00210086b5`
- Application SHA-256: `2b9815278597d09828c7d9e1697fc6a65c197e7ebf6940f1a24553f7f4f121f4`
- The partition table is byte-identical to the installed web-setup build.
  For this update, writing only `FoloToy-AI-Passport.bin` at `0x10000`
  preserves the existing NVS Wi-Fi configuration. Do not write this app-only
  file at `0x0`.

The saved Wi-Fi configuration survived the update and was retried automatically.
The new firmware logged `Wi-Fi station disconnected, reason=201` before reopening
setup. ESP-IDF defines 201 as `WIFI_REASON_NO_AP_FOUND`: no matching access point
was found. This does not establish whether the entered name differs, the network
is unavailable, or it is operating outside the device's supported band.

After the next user-operated setup attempt, a device photo showed
`LOOKING FOR MAC`, confirming that Wi-Fi had obtained an IP address. The iPhone
web-setup path is therefore working; the earlier reason 201 is a resolved test
failure, not the device's current state. The scan-list interaction itself was
not shown in a screenshot.

Mac integration then exposed two companion defects, now corrected: discovery
replies advertised the device's address rather than the Mac's routed address,
and the bitmap reader rejected the Mac's top-down 32-bit BI_BITFIELDS capture.
The companion now advertises the interface selected for the device, accepts
the verified BGR channel masks, and retries after capture errors. Nine host
tests cover discovery, image conversion, control timeouts, and recovery. A real Mac screenshot
was successfully converted to the 1152-byte preview, and the running local HTTP
state showed increasing preview revisions. Temporary capture-probe files were
removed after inspection. These companion-only fixes do not require reflashing.

The Mac subsequently observed repeated HTTP connections from the confirmed
device, and the user reported `CONNECTED`. Local discovery and the paired
firmware-to-companion connection have therefore passed a real LAN check.

The user then confirmed the on-device preview, but control initially failed in
WPS. A next-slide request reached the Mac and timed out in System Events;
Accessibility was disabled for the launching application, ChatGPT. With explicit
user approval, its Accessibility switch was enabled and the user completed the
system authentication. The companion now reports scripting timeouts as normal
HTTP errors and logs only validated control names and execution results.

After returning WPS to full-screen presentation, the user confirmed that all
four controls worked. The companion recorded successful `previous`, `next`,
`volume_up`, and `volume_down` executions. Preview rendering, WPS slide changes,
and both volume directions have therefore passed this user-assisted device test.

The complete gate was rerun after the companion fixes. Its latest additional verified
bundle is `build/firmware/825a14d514b7dc94b1d2c94449a3364b60669b507302e5b8b5d8317e5f7fb0fb/`,
with full-image SHA-256 `825a14d514b7dc94b1d2c94449a3364b60669b507302e5b8b5d8317e5f7fb0fb`
and ELF SHA-256 `acc0d793d921a61836be1b61c50140d0028bd844e43fd922c6d15f625609a96d`.
This additional validation build was not flashed; the hardware still runs the
`6abd236a...` image identified above.

Build: PASS. Host tests: PASS. Device tests: PASS for Wi-Fi setup, application
flashing/startup, numeric diagnostic logging, the paired Mac connection,
on-device preview, WPS previous/next, and volume up/down.
Unverified: visual scan list and failure label, firmware reconnect after another
restart, long-running stability, and the Wi-Fi reset gesture.
