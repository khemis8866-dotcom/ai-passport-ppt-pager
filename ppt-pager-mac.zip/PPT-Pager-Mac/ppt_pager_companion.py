#!/usr/bin/env python3
"""Local macOS companion for the FoloToy AI Passport PPT Pager firmware.

The companion intentionally stays on the local network.  It discovers a
paired device through UDP, exposes a tiny HTTP protocol, captures the current
display as a low-resolution monochrome PBM preview, and sends keyboard/volume
commands to macOS.  It uses only the Python standard library and macOS tools.
"""

from __future__ import annotations

import argparse
import hmac
import http.server
import os
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


DISCOVERY_PORT = 37986
DEFAULT_HTTP_PORT = 37987
PREVIEW_WIDTH = 128
PREVIEW_HEIGHT = 72
PREVIEW_BYTES = PREVIEW_WIDTH * PREVIEW_HEIGHT // 8


def valid_pair_code(code: str) -> bool:
    return len(code) == 6 and code.isdecimal()


def parse_discovery(message: bytes) -> Optional[str]:
    try:
        text = message.decode("ascii")
    except UnicodeDecodeError:
        return None
    pieces = text.strip().split()
    if len(pieces) == 3 and pieces[0] == "FPP/1" and pieces[1] == "DISCOVER":
        return pieces[2] if valid_pair_code(pieces[2]) else None
    return None


def pbm_header() -> bytes:
    return f"P4\n{PREVIEW_WIDTH} {PREVIEW_HEIGHT}\n".encode("ascii")


def bitmap_from_bmp(data: bytes, width: int = PREVIEW_WIDTH,
                    height: int = PREVIEW_HEIGHT) -> bytes:
    """Downsample a 24/32-bit BGR BMP into an MSB-first PBM bitmap."""
    if len(data) < 54 or data[:2] != b"BM":
        raise ValueError("expected a BMP file")
    pixel_offset = struct.unpack_from("<I", data, 10)[0]
    dib_size = struct.unpack_from("<I", data, 14)[0]
    if dib_size < 40 or pixel_offset < 14 + dib_size or len(data) < pixel_offset:
        raise ValueError("unsupported BMP header")
    source_width, source_height = struct.unpack_from("<ii", data, 18)
    planes, bits_per_pixel = struct.unpack_from("<HH", data, 26)
    compression = struct.unpack_from("<I", data, 30)[0]
    if source_width <= 0 or source_height == 0 or planes != 1:
        raise ValueError("invalid BMP geometry")
    if bits_per_pixel not in (24, 32) or compression not in (0, 3):
        raise ValueError("only 24/32-bit BGR BMP files are supported")
    if compression == 3:
        # macOS screencapture produces top-down BITMAPV5HEADER files using
        # BI_BITFIELDS, even though the pixels are ordinary B,G,R,A bytes.
        if bits_per_pixel != 32 or pixel_offset < 66:
            raise ValueError("unsupported BMP bitfield header")
        masks = struct.unpack_from("<III", data, 54)
        if masks != (0x00FF0000, 0x0000FF00, 0x000000FF):
            raise ValueError("unsupported BMP channel masks")

    top_down = source_height < 0
    source_height = abs(source_height)
    bytes_per_pixel = bits_per_pixel // 8
    source_stride = (source_width * bytes_per_pixel + 3) & ~3
    if pixel_offset + source_stride * source_height > len(data):
        raise ValueError("truncated BMP pixels")

    output = bytearray(width * height // 8)
    for y in range(height):
        source_y = min(source_height - 1, y * source_height // height)
        if not top_down:
            source_y = source_height - 1 - source_y
        row = pixel_offset + source_y * source_stride
        for x in range(width):
            source_x = min(source_width - 1, x * source_width // width)
            offset = row + source_x * bytes_per_pixel
            blue, green, red = data[offset:offset + 3]
            luminance = (red * 299 + green * 587 + blue * 114) // 1000
            if luminance < 152:
                output[y * (width // 8) + x // 8] |= 0x80 >> (x % 8)
    return bytes(output)


def capture_macos_preview() -> bytes:
    if sys.platform != "darwin":
        raise RuntimeError("this companion currently captures macOS displays only")
    with tempfile.TemporaryDirectory(prefix="ppt-pager-") as directory:
        image = Path(directory) / "screen.bmp"
        completed = subprocess.run(
            ["screencapture", "-x", "-t", "bmp", str(image)],
            capture_output=True,
            check=False,
            text=True,
            timeout=10,
        )
        if completed.returncode != 0 or not image.exists():
            reason = completed.stderr.strip() or "macOS screen capture failed"
            raise RuntimeError(reason)
        return bitmap_from_bmp(image.read_bytes())


def run_osascript(script: str) -> None:
    try:
        completed = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            check=False,
            text=True,
            timeout=5,
        )
    except subprocess.TimeoutExpired as error:
        raise RuntimeError(
            "macOS control timed out. Check Accessibility and Automation permissions."
        ) from error
    except OSError as error:
        raise RuntimeError(f"Could not start macOS control: {error}") from error
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "macOS automation was refused")


@dataclass
class PagerState:
    pair_code: str
    preview: bytes = field(default_factory=lambda: bytes(PREVIEW_BYTES))
    preview_revision: int = 0
    title: str = "LIVE SCREEN PREVIEW"
    last_error: str = ""
    lock: threading.Lock = field(default_factory=threading.Lock)

    def refresh_preview(self) -> None:
        try:
            preview = capture_macos_preview()
        except (RuntimeError, ValueError, OSError, subprocess.TimeoutExpired) as error:
            with self.lock:
                self.last_error = str(error)
                self.title = "SCREEN PREVIEW ERROR"
            return
        with self.lock:
            if preview != self.preview:
                self.preview = preview
                self.preview_revision += 1
            self.last_error = ""
            self.title = "LIVE SCREEN PREVIEW"

    def state_body(self) -> bytes:
        with self.lock:
            title = "".join(character for character in self.title if 32 <= ord(character) < 127)
            return f"FPPSTATE/1\npreview:{self.preview_revision}\ntitle:{title}\n".encode("ascii")

    def preview_body(self) -> bytes:
        with self.lock:
            return pbm_header() + self.preview

    def control(self, command: str) -> None:
        key_scripts = {
            "previous": 'tell application "System Events" to key code 123',
            "next": 'tell application "System Events" to key code 124',
            "volume_up": (
                "set currentVolume to output volume of (get volume settings)\n"
                "if currentVolume < 95 then\n"
                "  set volume output volume (currentVolume + 5)\n"
                "else\n"
                "  set volume output volume 100\n"
                "end if"
            ),
            "volume_down": (
                "set currentVolume to output volume of (get volume settings)\n"
                "if currentVolume > 5 then\n"
                "  set volume output volume (currentVolume - 5)\n"
                "else\n"
                "  set volume output volume 0\n"
                "end if"
            ),
        }
        if command not in key_scripts:
            raise ValueError("unsupported command")
        print(f"Control received: {command}", flush=True)
        run_osascript(key_scripts[command])
        print(f"Control completed: {command}", flush=True)


class CompanionHandler(http.server.BaseHTTPRequestHandler):
    server_version = "PPTPager/1"

    @property
    def pager(self) -> PagerState:
        return self.server.pager  # type: ignore[attr-defined]

    def log_message(self, format: str, *args: object) -> None:
        del format, args

    def authorized(self, query: dict[str, list[str]]) -> bool:
        supplied = query.get("code", [""])[0]
        return hmac.compare_digest(supplied, self.pager.pair_code)

    def respond(self, status: int, content_type: str, body: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 - HTTPServer interface spelling
        request = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(request.query)
        if not self.authorized(query):
            self.respond(403, "text/plain", b"forbidden\n")
            return
        if request.path == "/v1/state":
            self.respond(200, "text/plain; charset=us-ascii", self.pager.state_body())
        elif request.path == "/v1/preview":
            self.respond(200, "image/x-portable-bitmap", self.pager.preview_body())
        elif request.path == "/v1/control":
            command = query.get("command", [""])[0]
            try:
                self.pager.control(command)
            except (RuntimeError, ValueError) as error:
                print(f"Control failed: {error}", file=sys.stderr, flush=True)
                self.respond(409, "text/plain", f"{error}\n".encode("utf-8"))
                return
            self.respond(200, "text/plain", b"ok\n")
        else:
            self.respond(404, "text/plain", b"not found\n")


def run_preview_loop(pager: PagerState, interval: float) -> None:
    while True:
        pager.refresh_preview()
        time.sleep(interval)


def discovery_response(code: str, peer: tuple[str, int], http_port: int) -> bytes:
    # A wildcard-bound listener has no single LAN address. Ask the routing
    # table which local interface reaches this device; do not advertise peer[0],
    # which is the device's address. UDP connect selects a route without sending.
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
        route.connect(peer)
        local_address = route.getsockname()[0]
    return f"FPP/1 HOST {code} {local_address} {http_port}\n".encode("ascii")


def respond_to_discovery(pager: PagerState, http_port: int) -> None:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as listener:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("", DISCOVERY_PORT))
        while True:
            message, source = listener.recvfrom(128)
            code = parse_discovery(message)
            if code is None or not hmac.compare_digest(code, pager.pair_code):
                continue
            try:
                response = discovery_response(code, source, http_port)
                listener.sendto(response, source)
            except OSError as error:
                print(f"Discovery response failed: {error}", file=sys.stderr)


def run_server(pager: PagerState, bind: str, http_port: int, interval: float) -> None:
    preview_thread = threading.Thread(target=run_preview_loop, args=(pager, interval),
                                      daemon=True, name="ppt-preview")
    preview_thread.start()
    discovery_thread = threading.Thread(target=respond_to_discovery, args=(pager, http_port),
                                        daemon=True, name="ppt-discovery")
    discovery_thread.start()
    server = http.server.ThreadingHTTPServer((bind, http_port), CompanionHandler)
    server.pager = pager  # type: ignore[attr-defined]
    print(f"PPT Pager companion: HTTP {bind}:{http_port}, UDP {DISCOVERY_PORT}")
    print("Keep the slideshow window focused. Press Ctrl-C here to stop.")
    server.serve_forever()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--code", required=True, help="six-digit PAIR code shown on the AI Passport")
    parser.add_argument("--bind", default="0.0.0.0", help="LAN address to listen on")
    parser.add_argument("--port", default=DEFAULT_HTTP_PORT, type=int, help="HTTP listen port")
    parser.add_argument("--preview-interval", default=0.8, type=float,
                        help="seconds between display captures")
    arguments = parser.parse_args()
    if not valid_pair_code(arguments.code):
        parser.error("--code must contain exactly six digits")
    if not 1 <= arguments.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    if arguments.preview_interval <= 0:
        parser.error("--preview-interval must be positive")
    return arguments


def main() -> int:
    arguments = parse_args()
    pager = PagerState(pair_code=arguments.code)
    try:
        run_server(pager, arguments.bind, arguments.port, arguments.preview_interval)
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
