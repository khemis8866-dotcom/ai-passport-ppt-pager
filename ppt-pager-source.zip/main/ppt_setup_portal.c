#include "ppt_setup_portal.h"

#include <ctype.h>
#include <string.h>

static int hex_value(char character)
{
    if (character >= '0' && character <= '9') return character - '0';
    if (character >= 'a' && character <= 'f') return character - 'a' + 10;
    if (character >= 'A' && character <= 'F') return character - 'A' + 10;
    return -1;
}

static bool decode_component(char *output, size_t output_size, const char *input, size_t input_length)
{
    if (output == NULL || output_size == 0 || input == NULL) return false;
    size_t written = 0;
    for (size_t index = 0; index < input_length; ++index) {
        unsigned char character = (unsigned char)input[index];
        if (character == '+') {
            character = ' ';
        } else if (character == '%') {
            if (index + 2 >= input_length) return false;
            int high = hex_value(input[index + 1]);
            int low = hex_value(input[index + 2]);
            if (high < 0 || low < 0) return false;
            character = (unsigned char)((high << 4) | low);
            index += 2;
        }
        if (character == '\0' || written + 1 >= output_size) return false;
        output[written++] = (char)character;
    }
    output[written] = '\0';
    return true;
}

static bool password_valid(const char *password)
{
    size_t length = strlen(password);
    if (length == 0 || (length >= 8 && length <= 63)) return true;
    if (length != 64) return false;
    for (size_t index = 0; index < length; ++index) {
        if (!isxdigit((unsigned char)password[index])) return false;
    }
    return true;
}

bool ppt_setup_html_escape(const char *input, size_t length, char *output, size_t output_size)
{
    if (input == NULL || output == NULL || output_size == 0) return false;
    size_t used = 0;
    output[0] = '\0';
    for (size_t index = 0; index < length; ++index) {
        const char *escaped = NULL;
        switch (input[index]) {
        case '&': escaped = "&amp;"; break;
        case '<': escaped = "&lt;"; break;
        case '>': escaped = "&gt;"; break;
        case '"': escaped = "&quot;"; break;
        case '\'': escaped = "&#39;"; break;
        case '\0': return false;
        default: break;
        }
        size_t count = escaped == NULL ? 1 : strlen(escaped);
        if (count >= output_size - used) return false;
        if (escaped == NULL) output[used] = input[index];
        else memcpy(output + used, escaped, count);
        used += count;
        output[used] = '\0';
    }
    return true;
}

bool ppt_setup_parse_form(const char *body, size_t length, ppt_setup_credentials_t *credentials)
{
    if (body == NULL || credentials == NULL || length == 0) return false;
    memset(credentials, 0, sizeof(*credentials));
    bool has_ssid = false;
    bool has_password = false;
    size_t offset = 0;

    while (offset < length) {
        size_t field_end = offset;
        while (field_end < length && body[field_end] != '&') ++field_end;
        size_t equals = offset;
        while (equals < field_end && body[equals] != '=') ++equals;
        if (equals == offset || equals == field_end) return false;

        const char *value = body + equals + 1;
        size_t value_length = field_end - equals - 1;
        if (equals - offset == 4 && memcmp(body + offset, "ssid", 4) == 0) {
            if (has_ssid || !decode_component(credentials->ssid, sizeof(credentials->ssid),
                                               value, value_length)) {
                return false;
            }
            has_ssid = true;
        } else if (equals - offset == 8 && memcmp(body + offset, "password", 8) == 0) {
            if (has_password || !decode_component(credentials->password,
                                                   sizeof(credentials->password), value,
                                                   value_length)) {
                return false;
            }
            has_password = true;
        } else {
            return false;
        }
        offset = field_end + 1;
    }
    return has_ssid && credentials->ssid[0] != '\0' && password_valid(credentials->password);
}
