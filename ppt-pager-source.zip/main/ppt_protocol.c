#include "ppt_protocol.h"

#include <ctype.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

static bool line_matches(const char *line, size_t length, const char *text)
{
    size_t expected = strlen(text);
    return length == expected && memcmp(line, text, expected) == 0;
}

bool ppt_protocol_pair_code_valid(const char *code)
{
    if (code == NULL || strlen(code) != PPT_PROTOCOL_PAIR_CODE_LENGTH) return false;
    for (size_t i = 0; i < PPT_PROTOCOL_PAIR_CODE_LENGTH; ++i) {
        if (!isdigit((unsigned char)code[i])) return false;
    }
    return true;
}

bool ppt_protocol_format_discovery(const char *code, char *out, size_t out_size)
{
    if (!ppt_protocol_pair_code_valid(code) || out == NULL) return false;
    int written = snprintf(out, out_size, "FPP/1 DISCOVER %s\n", code);
    return written > 0 && (size_t)written < out_size;
}

static bool valid_ipv4(const char *host)
{
    unsigned octets[4];
    char extra;
    return sscanf(host, "%u.%u.%u.%u%c", &octets[0], &octets[1], &octets[2],
                  &octets[3], &extra) == 4 && octets[0] <= 255 && octets[1] <= 255 &&
           octets[2] <= 255 && octets[3] <= 255;
}

bool ppt_protocol_parse_host(const char *message, size_t length, const char *code,
                             ppt_protocol_host_t *out)
{
    if (message == NULL || code == NULL || out == NULL || length == 0 || length > 96 ||
        !ppt_protocol_pair_code_valid(code)) {
        return false;
    }
    char copy[97];
    memcpy(copy, message, length);
    copy[length] = '\0';

    char received_code[8] = {0};
    char host[PPT_PROTOCOL_HOST_MAX] = {0};
    unsigned port = 0;
    if (sscanf(copy, "FPP/1 HOST %7s %15s %u", received_code, host, &port) != 3 ||
        strcmp(received_code, code) != 0 || !valid_ipv4(host) || port == 0 || port > 65535) {
        return false;
    }
    memcpy(out->host, host, sizeof(out->host));
    out->port = (uint16_t)port;
    return true;
}

bool ppt_protocol_parse_state(const char *body, size_t length, ppt_protocol_state_t *out)
{
    if (body == NULL || out == NULL || length == 0 || length > 512) return false;
    memset(out, 0, sizeof(*out));

    bool header = false;
    bool preview = false;
    size_t at = 0;
    while (at < length) {
        size_t end = at;
        while (end < length && body[end] != '\n') ++end;
        size_t line_length = end - at;
        if (line_length > 0 && body[at + line_length - 1] == '\r') --line_length;

        if (!header) {
            header = line_matches(body + at, line_length, "FPPSTATE/1");
            if (!header) return false;
        } else if (line_length >= 8 && memcmp(body + at, "preview:", 8) == 0) {
            char number[16] = {0};
            size_t amount = line_length - 8;
            if (amount == 0 || amount >= sizeof(number)) return false;
            memcpy(number, body + at + 8, amount);
            char extra;
            if (sscanf(number, "%" SCNu32 "%c", &out->preview_revision, &extra) != 1) {
                return false;
            }
            preview = true;
        } else if (line_length >= 6 && memcmp(body + at, "title:", 6) == 0) {
            size_t amount = line_length - 6;
            if (amount >= sizeof(out->title)) amount = sizeof(out->title) - 1;
            memcpy(out->title, body + at + 6, amount);
            out->title[amount] = '\0';
        }
        at = end + 1;
    }
    return header && preview;
}

const char *ppt_protocol_command_name(ppt_protocol_command_t command)
{
    switch (command) {
    case PPT_PROTOCOL_COMMAND_PREVIOUS: return "previous";
    case PPT_PROTOCOL_COMMAND_NEXT: return "next";
    case PPT_PROTOCOL_COMMAND_VOLUME_UP: return "volume_up";
    case PPT_PROTOCOL_COMMAND_VOLUME_DOWN: return "volume_down";
    }
    return NULL;
}

bool ppt_protocol_pbm_payload(const uint8_t *body, size_t length,
                              const uint8_t **pixels, size_t *pixel_length)
{
    static const char header[] = "P4\n128 72\n";
    const size_t header_length = sizeof(header) - 1;
    if (body == NULL || pixels == NULL || pixel_length == NULL ||
        length != header_length + PPT_PROTOCOL_PREVIEW_BYTES ||
        memcmp(body, header, header_length) != 0) {
        return false;
    }
    *pixels = body + header_length;
    *pixel_length = PPT_PROTOCOL_PREVIEW_BYTES;
    return true;
}
