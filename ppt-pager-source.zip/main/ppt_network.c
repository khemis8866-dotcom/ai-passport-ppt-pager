#include "ppt_network.h"

#include "ppt_setup_portal.h"

#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_random.h"
#include "esp_wifi.h"
#include "esp_wifi_default.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lwip/inet.h"
#include "lwip/ip4_addr.h"
#include "lwip/sockets.h"
#include "nvs_flash.h"

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "ppt_network";

#define PPT_DISCOVERY_PORT 37986
#define PPT_DEFAULT_HTTP_PORT 37987
#define PPT_HTTP_BODY_MAX 1400
#define PPT_COMMAND_QUEUE_DEPTH 4
#define PPT_PORTAL_FORM_MAX 320
#define PPT_PORTAL_HTTP_PORT 80
#define PPT_PORTAL_SCAN_COUNT 16

typedef struct {
    char data[PPT_HTTP_BODY_MAX];
    size_t length;
    bool overflow;
} http_body_t;

static ppt_network_callbacks_t s_callbacks;
static esp_netif_t *s_sta_netif;
static esp_netif_t *s_ap_netif;
static esp_event_handler_instance_t s_wifi_handler;
static esp_event_handler_instance_t s_ip_handler;
static wifi_config_t s_sta_config;
static QueueHandle_t s_command_queue;
static TaskHandle_t s_poll_task;
static httpd_handle_t s_portal_server;
static bool s_nvs_ready;
static bool s_netif_ready;
static bool s_event_loop_ready;
static bool s_wifi_initialized;
static bool s_wifi_started;
static bool s_wifi_handler_registered;
static bool s_ip_handler_registered;
static bool s_wifi_got_ip;
static bool s_portal_connecting;
static uint16_t s_wifi_disconnect_reason;
static char s_wifi_failure[32];
static bool s_started;
static ppt_protocol_host_t s_host;
static uint32_t s_preview_revision;
static char s_pair_code[PPT_PROTOCOL_PAIR_CODE_LENGTH + 1];
static char s_setup_ssid[PPT_NETWORK_SETUP_SSID_MAX + 1];
static char s_setup_password[PPT_NETWORK_SETUP_PASSWORD_MAX + 1];
static char s_ip[16];
static char s_title[PPT_PROTOCOL_TITLE_MAX];

static void ppt_network_poll_task(void *arg);
static esp_err_t start_setup_portal(void);

static void report(ppt_network_state_t state, esp_err_t error)
{
    if (s_callbacks.status == NULL) return;
    ppt_network_status_t status = {
        .state = state,
        .error = error,
    };
    memcpy(status.pair_code, s_pair_code, sizeof(status.pair_code));
    memcpy(status.setup_ssid, s_setup_ssid, sizeof(status.setup_ssid));
    memcpy(status.setup_password, s_setup_password, sizeof(status.setup_password));
    memcpy(status.wifi_failure, s_wifi_failure, sizeof(status.wifi_failure));
    memcpy(status.ip, s_ip, sizeof(status.ip));
    memcpy(status.title, s_title, sizeof(status.title));
    s_callbacks.status(&status, s_callbacks.context);
}

static esp_err_t radio_prepare(void)
{
    if (!s_nvs_ready) {
        esp_err_t err = nvs_flash_init();
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "NVS init failed: %s", esp_err_to_name(err));
            return err;
        }
        s_nvs_ready = true;
    }
    if (!s_netif_ready) {
        esp_err_t err = esp_netif_init();
        if (err != ESP_OK) return err;
        s_netif_ready = true;
    }
    if (!s_event_loop_ready) {
        esp_err_t err = esp_event_loop_create_default();
        if (err != ESP_OK) return err;
        s_event_loop_ready = true;
    }
    return ESP_OK;
}

static void reset_link_state(void)
{
    s_wifi_got_ip = false;
    s_ip[0] = '\0';
    s_host.host[0] = '\0';
    s_preview_revision = 0;
    s_title[0] = '\0';
}

static esp_err_t wifi_request_connect(void)
{
    reset_link_state();
    s_wifi_disconnect_reason = 0;
    s_wifi_failure[0] = '\0';
    s_portal_connecting = true;
    report(PPT_NETWORK_CONNECTING, ESP_OK);
    esp_err_t err = esp_wifi_connect();
    if (err != ESP_OK) {
        s_portal_connecting = false;
        ESP_LOGW(TAG, "could not start Wi-Fi connection: %s", esp_err_to_name(err));
        report(PPT_NETWORK_ERROR, err);
    }
    return err;
}

static const char *wifi_failure_label(uint16_t reason)
{
    switch (reason) {
    case WIFI_REASON_NO_AP_FOUND: return "NO WI-FI FOUND";
    case WIFI_REASON_AUTH_FAIL:
    case WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT:
    case WIFI_REASON_HANDSHAKE_TIMEOUT: return "CHECK PASSWORD";
    case WIFI_REASON_NO_AP_FOUND_W_COMPATIBLE_SECURITY:
    case WIFI_REASON_NO_AP_FOUND_IN_AUTHMODE_THRESHOLD: return "WI-FI SECURITY";
    case WIFI_REASON_NO_AP_FOUND_IN_RSSI_THRESHOLD: return "WEAK WI-FI";
    case WIFI_REASON_BEACON_TIMEOUT: return "WI-FI LINK LOST";
    default: return "WI-FI FAILED";
    }
}

static esp_err_t portal_send_page(httpd_req_t *request, const char *body)
{
    httpd_resp_set_type(request, "text/html; charset=utf-8");
    httpd_resp_set_hdr(request, "Cache-Control", "no-store");
    return httpd_resp_sendstr(request, body);
}

static esp_err_t portal_unavailable(httpd_req_t *request, const char *message)
{
    httpd_resp_set_status(request, "503 Service Unavailable");
    httpd_resp_set_type(request, "text/plain; charset=us-ascii");
    return httpd_resp_sendstr(request, message);
}

static esp_err_t portal_root_handler(httpd_req_t *request)
{
    static const char page[] =
        "<!doctype html><html><head><meta charset=utf-8>"
        "<meta name=viewport content='width=device-width,initial-scale=1'>"
        "<title>PPT Pager Wi-Fi</title><style>body{max-width:34rem;margin:2rem auto;"
        "font-family:-apple-system,BlinkMacSystemFont,sans-serif;padding:0 1rem;line-height:1.5}"
        "input,select{box-sizing:border-box;width:100%;padding:.75rem;margin:.35rem 0 1rem;"
        "font-size:1rem}button{width:100%;padding:.8rem;background:#087f5b;color:#fff;"
        "border:0;border-radius:.4rem;font-size:1rem}</style></head><body>"
        "<h1>PPT Pager Wi-Fi setup</h1><p>Enter the exact name and password of the "
        "2.4 GHz Wi-Fi network that your Mac uses. Choose it from the list to keep "
        "its exact spelling. Leave the password blank only for an open network.</p>"
        "<p id=status aria-live=polite></p><button id=scan type=button>Scan nearby Wi-Fi</button>"
        "<label>Nearby 2.4 GHz Wi-Fi<select id=networks><option value=''>Choose a network"
        "</option></select></label><form method=post action=/configure>"
        "<label>Wi-Fi name (SSID)<input id=ssid name=ssid maxlength=32 required "
        "autocomplete=off autocapitalize=none autocorrect=off spellcheck=false></label>"
        "<label>Wi-Fi password<input name=password type=password maxlength=64 "
        "autocomplete=current-password></label><button type=submit>Connect PPT Pager</button>"
        "</form><p>After the device connects, rejoin your normal Wi-Fi on this iPhone. "
        "The device and Mac must be on the same local network.</p>"
        "<script>const list=document.getElementById('networks'),"
        "ssid=document.getElementById('ssid'),scan=document.getElementById('scan'),"
        "status=document.getElementById('status');"
        "list.onchange=()=>{if(list.value)ssid.value=list.value};"
        "async function refresh(){try{status.textContent=await(await fetch('/status',"
        "{cache:'no-store'})).text()}catch(e){}}"
        "scan.onclick=async()=>{scan.disabled=true;scan.textContent='Scanning...';try{"
        "const r=await fetch('/networks',{cache:'no-store'});if(!r.ok)throw Error(await r.text());"
        "list.innerHTML='<option value=\"\">Choose a network</option>'+await r.text();"
        "}catch(e){status.textContent='Scan unavailable. '+e.message}finally{"
        "scan.disabled=false;scan.textContent='Scan nearby Wi-Fi'}};"
        "refresh();scan.click();</script></body></html>";
    return portal_send_page(request, page);
}

static esp_err_t portal_status_handler(httpd_req_t *request)
{
    char state[256];
    if (s_portal_connecting) {
        snprintf(state, sizeof(state), "Connecting. Check the device screen for the result.");
    } else if (s_wifi_disconnect_reason != 0) {
        const char *help = "Check the router and try again.";
        if (s_wifi_disconnect_reason == WIFI_REASON_NO_AP_FOUND) {
            help = "Select the exact name from nearby 2.4 GHz networks. A 5 GHz-only network will not appear.";
        } else if (s_wifi_disconnect_reason == WIFI_REASON_AUTH_FAIL ||
                   s_wifi_disconnect_reason == WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT ||
                   s_wifi_disconnect_reason == WIFI_REASON_HANDSHAKE_TIMEOUT) {
            help = "Check the password and router security settings. Authentication did not complete.";
        }
        snprintf(state, sizeof(state), "%s. %s", s_wifi_failure, help);
    } else {
        snprintf(state, sizeof(state), "Choose the same 2.4 GHz network as your Mac.");
    }
    httpd_resp_set_type(request, "text/plain; charset=us-ascii");
    httpd_resp_set_hdr(request, "Cache-Control", "no-store");
    return httpd_resp_sendstr(request, state);
}

static esp_err_t portal_networks_handler(httpd_req_t *request)
{
    if (s_portal_connecting) {
        return portal_unavailable(request, "A connection is in progress.");
    }
    wifi_ap_record_t *records = calloc(PPT_PORTAL_SCAN_COUNT, sizeof(*records));
    if (records == NULL) return portal_unavailable(request, "Not enough memory to scan. Try again.");
    wifi_scan_config_t config = {0};
    config.scan_time.active.max = 120;
    esp_err_t err = esp_wifi_scan_start(&config, true);
    uint16_t count = PPT_PORTAL_SCAN_COUNT;
    if (err == ESP_OK) err = esp_wifi_scan_get_ap_records(&count, records);
    if (err != ESP_OK) {
        (void)esp_wifi_clear_ap_list();
        free(records);
        ESP_LOGW(TAG, "setup network scan failed: %s", esp_err_to_name(err));
        return portal_unavailable(request, "Could not scan. Try again.");
    }
    ESP_LOGI(TAG, "setup scan completed: %u visible networks", count);
    httpd_resp_set_type(request, "text/html; charset=utf-8");
    httpd_resp_set_hdr(request, "Cache-Control", "no-store");
    for (uint16_t index = 0; index < count && err == ESP_OK; ++index) {
        size_t length = strnlen((const char *)records[index].ssid, PPT_SETUP_SSID_MAX);
        if (length == 0) continue;
        bool duplicate = false;
        for (uint16_t previous = 0; previous < index; ++previous) {
            if (memcmp(records[previous].ssid, records[index].ssid, 33) == 0) duplicate = true;
        }
        if (duplicate) continue;
        char escaped[PPT_SETUP_SSID_MAX * 6 + 1];
        char option[PPT_SETUP_SSID_MAX * 12 + 64];
        if (!ppt_setup_html_escape((const char *)records[index].ssid, length, escaped, sizeof(escaped))) {
            continue;
        }
        snprintf(option, sizeof(option), "<option value=\"%s\">%s (%d dBm)</option>",
                 escaped, escaped, records[index].rssi);
        err = httpd_resp_sendstr_chunk(request, option);
    }
    free(records);
    if (err == ESP_OK) err = httpd_resp_send_chunk(request, NULL, 0);
    return err;
}

static esp_err_t portal_read_body(httpd_req_t *request, char *body, size_t body_size)
{
    if (request->content_len <= 0 || request->content_len >= (ssize_t)body_size) {
        return ESP_ERR_INVALID_SIZE;
    }
    size_t received = 0;
    while (received < (size_t)request->content_len) {
        int count = httpd_req_recv(request, body + received,
                                   request->content_len - (ssize_t)received);
        if (count <= 0) return ESP_FAIL;
        received += (size_t)count;
    }
    body[received] = '\0';
    return ESP_OK;
}

static esp_err_t portal_submit_handler(httpd_req_t *request)
{
    char body[PPT_PORTAL_FORM_MAX];
    ppt_setup_credentials_t credentials;
    esp_err_t err = portal_read_body(request, body, sizeof(body));
    if (err != ESP_OK || !ppt_setup_parse_form(body, strlen(body), &credentials)) {
        memset(body, 0, sizeof(body));
        memset(&credentials, 0, sizeof(credentials));
        httpd_resp_send_err(request, HTTPD_400_BAD_REQUEST, "Check the Wi-Fi name and password.");
        return ESP_FAIL;
    }

    wifi_config_t next_config = {0};
    memcpy(next_config.sta.ssid, credentials.ssid, strlen(credentials.ssid));
    memcpy(next_config.sta.password, credentials.password, strlen(credentials.password));
    next_config.sta.threshold.authmode = WIFI_AUTH_OPEN;
    err = esp_wifi_set_config(WIFI_IF_STA, &next_config);
    if (err == ESP_OK) {
        s_sta_config = next_config;
        ESP_LOGI(TAG, "received local Wi-Fi setup request");
        err = wifi_request_connect();
    }
    memset(body, 0, sizeof(body));
    memset(&credentials, 0, sizeof(credentials));
    memset(&next_config, 0, sizeof(next_config));
    if (err != ESP_OK) {
        httpd_resp_send_err(request, HTTPD_500_INTERNAL_SERVER_ERROR,
                            "The device could not start Wi-Fi connection.");
        return err;
    }

    static const char response[] =
        "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
        "<title>Connecting</title><body style='font-family:-apple-system,BlinkMacSystemFont,sans-serif;"
        "max-width:34rem;margin:2rem auto;padding:0 1rem;line-height:1.5'><h1>Connecting</h1>"
        "<p>The PPT Pager is joining the Wi-Fi network. Check its screen. Once it shows "
        "LOOKING FOR MAC or CONNECTED, reconnect this iPhone to your normal Wi-Fi.</p>"
        "<p id=status aria-live=polite></p><p><a href='/'>Choose Wi-Fi again</a></p>"
        "<script>setInterval(async()=>{try{document.getElementById('status').textContent="
        "await(await fetch('/status',{cache:'no-store'})).text()}catch(e){}},1500)</script></body>";
    return portal_send_page(request, response);
}

static const httpd_uri_t s_portal_root = {
    .uri = "/",
    .method = HTTP_GET,
    .handler = portal_root_handler,
    .user_ctx = NULL,
};

static const httpd_uri_t s_portal_status = {
    .uri = "/status",
    .method = HTTP_GET,
    .handler = portal_status_handler,
    .user_ctx = NULL,
};

static const httpd_uri_t s_portal_submit = {
    .uri = "/configure",
    .method = HTTP_POST,
    .handler = portal_submit_handler,
    .user_ctx = NULL,
};

static const httpd_uri_t s_portal_networks = {
    .uri = "/networks",
    .method = HTTP_GET,
    .handler = portal_networks_handler,
    .user_ctx = NULL,
};

static esp_err_t portal_server_start(void)
{
    if (s_portal_server != NULL) return ESP_OK;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = PPT_PORTAL_HTTP_PORT;
    config.max_uri_handlers = 4;
    config.stack_size = 4096;
    config.lru_purge_enable = true;
    esp_err_t err = httpd_start(&s_portal_server, &config);
    if (err != ESP_OK) return err;
    err = httpd_register_uri_handler(s_portal_server, &s_portal_root);
    if (err == ESP_OK) err = httpd_register_uri_handler(s_portal_server, &s_portal_status);
    if (err == ESP_OK) err = httpd_register_uri_handler(s_portal_server, &s_portal_submit);
    if (err == ESP_OK) err = httpd_register_uri_handler(s_portal_server, &s_portal_networks);
    if (err != ESP_OK) {
        httpd_stop(s_portal_server);
        s_portal_server = NULL;
    }
    return err;
}

static void portal_server_stop(void)
{
    if (s_portal_server == NULL) return;
    httpd_stop(s_portal_server);
    s_portal_server = NULL;
}

static void portal_stop_after_connect(void)
{
    portal_server_stop();
    s_portal_connecting = false;
    if (s_wifi_started) {
        esp_err_t err = esp_wifi_set_mode(WIFI_MODE_STA);
        if (err != ESP_OK) ESP_LOGW(TAG, "could not stop setup access point: %s", esp_err_to_name(err));
    }
}

static void generate_setup_credentials(void)
{
    uint8_t mac[6] = {0};
    if (esp_wifi_get_mac(WIFI_IF_STA, mac) == ESP_OK) {
        snprintf(s_setup_ssid, sizeof(s_setup_ssid), "PPTPager-%02X%02X", mac[4], mac[5]);
    } else {
        snprintf(s_setup_ssid, sizeof(s_setup_ssid), "PPTPager-Setup");
    }
    snprintf(s_setup_password, sizeof(s_setup_password), "PPT%s", s_pair_code);
}

static esp_err_t start_setup_portal(void)
{
    if (!s_wifi_initialized) return ESP_ERR_INVALID_STATE;
    if (s_ap_netif == NULL) {
        s_ap_netif = esp_netif_create_default_wifi_ap();
        if (s_ap_netif == NULL) return ESP_ERR_NO_MEM;
    }

    wifi_config_t ap_config = {0};
    memcpy(ap_config.ap.ssid, s_setup_ssid, strlen(s_setup_ssid));
    memcpy(ap_config.ap.password, s_setup_password, strlen(s_setup_password));
    ap_config.ap.ssid_len = strlen(s_setup_ssid);
    ap_config.ap.channel = 1;
    ap_config.ap.max_connection = 4;
    ap_config.ap.authmode = WIFI_AUTH_WPA2_PSK;

    esp_err_t err = esp_wifi_set_mode(WIFI_MODE_APSTA);
    if (err == ESP_OK) err = esp_wifi_set_config(WIFI_IF_AP, &ap_config);
    if (err == ESP_OK && !s_wifi_started) {
        err = esp_wifi_start();
        if (err == ESP_OK) s_wifi_started = true;
    }
    if (err == ESP_OK) err = portal_server_start();
    if (err == ESP_OK) {
        s_portal_connecting = false;
        report(PPT_NETWORK_PROVISIONING, ESP_OK);
    }
    memset(&ap_config, 0, sizeof(ap_config));
    return err;
}

static void wifi_event(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    (void)base;
    if (id == WIFI_EVENT_STA_START) {
        esp_wifi_get_config(WIFI_IF_STA, &s_sta_config);
        if (s_sta_config.sta.ssid[0] != '\0') {
            wifi_request_connect();
        }
    } else if (id == WIFI_EVENT_STA_DISCONNECTED) {
        const wifi_event_sta_disconnected_t *event = data;
        s_wifi_disconnect_reason = event != NULL ? event->reason : WIFI_REASON_UNSPECIFIED;
        snprintf(s_wifi_failure, sizeof(s_wifi_failure), "%s %u",
                 wifi_failure_label(s_wifi_disconnect_reason), s_wifi_disconnect_reason);
        ESP_LOGW(TAG, "Wi-Fi station disconnected, reason=%u", s_wifi_disconnect_reason);
        reset_link_state();
        if (s_started) {
            esp_err_t err = start_setup_portal();
            if (err != ESP_OK) report(PPT_NETWORK_ERROR, err);
        }
    }
}

static void ip_event(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    (void)base;
    if (id != IP_EVENT_STA_GOT_IP) return;
    ip_event_got_ip_t *event = data;
    snprintf(s_ip, sizeof(s_ip), IPSTR, IP2STR(&event->ip_info.ip));
    s_wifi_got_ip = true;
    s_wifi_disconnect_reason = 0;
    s_wifi_failure[0] = '\0';
    ESP_LOGI(TAG, "Wi-Fi station obtained an IP address");
    portal_stop_after_connect();
    report(PPT_NETWORK_DISCOVERING, ESP_OK);
    if (s_poll_task == NULL) {
        if (xTaskCreate(ppt_network_poll_task, "ppt_network", 6144, NULL, 4,
                        &s_poll_task) != pdPASS) {
            s_poll_task = NULL;
            report(PPT_NETWORK_ERROR, ESP_ERR_NO_MEM);
        }
    }
}

static esp_err_t collect_http_data(esp_http_client_event_t *event)
{
    http_body_t *body = event->user_data;
    if (event->event_id != HTTP_EVENT_ON_DATA || body == NULL || event->data_len <= 0) {
        return ESP_OK;
    }
    if ((size_t)event->data_len > sizeof(body->data) - body->length) {
        body->overflow = true;
        return ESP_ERR_NO_MEM;
    }
    memcpy(body->data + body->length, event->data, (size_t)event->data_len);
    body->length += (size_t)event->data_len;
    return ESP_OK;
}

static esp_err_t http_get(const char *path, http_body_t *body)
{
    char url[128];
    int length = snprintf(url, sizeof(url), "http://%s:%u%s", s_host.host, s_host.port, path);
    if (length <= 0 || (size_t)length >= sizeof(url)) return ESP_ERR_INVALID_SIZE;
    memset(body, 0, sizeof(*body));
    esp_http_client_config_t config = {
        .url = url,
        .event_handler = collect_http_data,
        .user_data = body,
        .timeout_ms = 1800,
        .disable_auto_redirect = true,
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL) return ESP_ERR_NO_MEM;
    esp_err_t err = esp_http_client_perform(client);
    int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    if (err != ESP_OK) return err;
    if (body->overflow || status != 200) return ESP_FAIL;
    return ESP_OK;
}

static void request_path(char *path, size_t path_size, const char *endpoint)
{
    snprintf(path, path_size, "%s?code=%s", endpoint, s_pair_code);
}

static void poll_state(void)
{
    char path[64];
    http_body_t body;
    request_path(path, sizeof(path), "/v1/state");
    esp_err_t err = http_get(path, &body);
    ppt_protocol_state_t state;
    if (err != ESP_OK || !ppt_protocol_parse_state(body.data, body.length, &state)) {
        report(PPT_NETWORK_DISCOVERING, err == ESP_OK ? ESP_FAIL : err);
        return;
    }
    memcpy(s_title, state.title, sizeof(s_title));
    report(PPT_NETWORK_LINKED, ESP_OK);
    if (state.preview_revision == s_preview_revision) return;

    request_path(path, sizeof(path), "/v1/preview");
    err = http_get(path, &body);
    const uint8_t *pixels;
    size_t bytes;
    if (err != ESP_OK || !ppt_protocol_pbm_payload((const uint8_t *)body.data, body.length,
                                                    &pixels, &bytes)) {
        report(PPT_NETWORK_LINKED, err == ESP_OK ? ESP_FAIL : err);
        return;
    }
    s_preview_revision = state.preview_revision;
    if (s_callbacks.preview != NULL) {
        s_callbacks.preview(s_preview_revision, pixels, s_callbacks.context);
    }
}

static void send_command(ppt_protocol_command_t command)
{
    const char *name = ppt_protocol_command_name(command);
    if (name == NULL || s_host.host[0] == '\0') return;
    char path[96];
    snprintf(path, sizeof(path), "/v1/control?code=%s&command=%s", s_pair_code, name);
    http_body_t body;
    if (http_get(path, &body) != ESP_OK) report(PPT_NETWORK_DISCOVERING, ESP_FAIL);
}

static void receive_host(int socket_fd)
{
    char message[96];
    struct sockaddr_in source = {0};
    socklen_t source_length = sizeof(source);
    int received = recvfrom(socket_fd, message, sizeof(message), 0,
                            (struct sockaddr *)&source, &source_length);
    if (received <= 0) return;
    ppt_protocol_host_t candidate;
    if (ppt_protocol_parse_host(message, (size_t)received, s_pair_code, &candidate)) {
        s_host = candidate;
        s_preview_revision = 0;
        report(PPT_NETWORK_DISCOVERING, ESP_OK);
    }
}

static void broadcast_discovery(int socket_fd)
{
    char message[48];
    if (!ppt_protocol_format_discovery(s_pair_code, message, sizeof(message))) return;
    struct sockaddr_in destination = {
        .sin_family = AF_INET,
        .sin_port = htons(PPT_DISCOVERY_PORT),
        .sin_addr.s_addr = htonl(INADDR_BROADCAST),
    };
    (void)sendto(socket_fd, message, strlen(message), 0,
                 (struct sockaddr *)&destination, sizeof(destination));
}

static void ppt_network_poll_task(void *arg)
{
    (void)arg;
    int socket_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (socket_fd < 0) {
        report(PPT_NETWORK_ERROR, ESP_FAIL);
        s_poll_task = NULL;
        vTaskDelete(NULL);
        return;
    }
    int enabled = 1;
    setsockopt(socket_fd, SOL_SOCKET, SO_BROADCAST, &enabled, sizeof(enabled));
    TickType_t last_discovery = 0;
    for (;;) {
        if (!s_wifi_got_ip) {
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }
        TickType_t now = xTaskGetTickCount();
        if (s_host.host[0] == '\0' &&
            (now - last_discovery) >= pdMS_TO_TICKS(1000)) {
            broadcast_discovery(socket_fd);
            last_discovery = now;
        }
        struct timeval timeout = { .tv_sec = 0, .tv_usec = 150000 };
        fd_set descriptors;
        FD_ZERO(&descriptors);
        FD_SET(socket_fd, &descriptors);
        if (select(socket_fd + 1, &descriptors, NULL, NULL, &timeout) > 0) {
            receive_host(socket_fd);
        }
        ppt_protocol_command_t command;
        while (xQueueReceive(s_command_queue, &command, 0) == pdTRUE) {
            send_command(command);
        }
        if (s_host.host[0] != '\0') poll_state();
        vTaskDelay(pdMS_TO_TICKS(350));
    }
}

esp_err_t ppt_network_start(const ppt_network_callbacks_t *callbacks)
{
    if (callbacks == NULL || callbacks->status == NULL || s_started) return ESP_ERR_INVALID_ARG;
    s_callbacks = *callbacks;
    snprintf(s_pair_code, sizeof(s_pair_code), "%06" PRIu32,
             esp_random() % 1000000UL);
    report(PPT_NETWORK_STARTING, ESP_OK);

    esp_err_t err = radio_prepare();
    if (err != ESP_OK) goto fail;
    s_command_queue = xQueueCreate(PPT_COMMAND_QUEUE_DEPTH, sizeof(ppt_protocol_command_t));
    if (s_command_queue == NULL) {
        err = ESP_ERR_NO_MEM;
        goto fail;
    }
    s_sta_netif = esp_netif_create_default_wifi_sta();
    if (s_sta_netif == NULL) {
        err = ESP_ERR_NO_MEM;
        goto fail;
    }
    wifi_init_config_t wifi_config = WIFI_INIT_CONFIG_DEFAULT();
    err = esp_wifi_init(&wifi_config);
    if (err != ESP_OK) goto fail;
    s_wifi_initialized = true;
    generate_setup_credentials();
    err = esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_event, NULL,
                                              &s_wifi_handler);
    if (err != ESP_OK) goto fail;
    s_wifi_handler_registered = true;
    err = esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, ip_event, NULL,
                                              &s_ip_handler);
    if (err != ESP_OK) goto fail;
    s_ip_handler_registered = true;
    err = esp_wifi_set_storage(WIFI_STORAGE_FLASH);
    if (err != ESP_OK) goto fail;
    err = esp_wifi_get_config(WIFI_IF_STA, &s_sta_config);
    if (err != ESP_OK) goto fail;
    s_started = true;
    if (s_sta_config.sta.ssid[0] == '\0') {
        err = start_setup_portal();
    } else {
        err = esp_wifi_set_mode(WIFI_MODE_STA);
        if (err == ESP_OK) err = esp_wifi_start();
        if (err == ESP_OK) s_wifi_started = true;
    }
    if (err != ESP_OK) goto fail;
    return ESP_OK;

fail:
    s_started = false;
    report(PPT_NETWORK_ERROR, err);
    return err;
}

esp_err_t ppt_network_send_command(ppt_protocol_command_t command)
{
    if (!s_started || s_command_queue == NULL) return ESP_ERR_INVALID_STATE;
    return xQueueSend(s_command_queue, &command, 0) == pdTRUE ? ESP_OK : ESP_ERR_TIMEOUT;
}

esp_err_t ppt_network_clear_wifi(void)
{
    if (!s_wifi_started) return ESP_ERR_INVALID_STATE;
    wifi_config_t empty = {0};
    reset_link_state();
    (void)esp_wifi_disconnect();
    esp_err_t err = esp_wifi_set_config(WIFI_IF_STA, &empty);
    if (err == ESP_OK) {
        memset(&s_sta_config, 0, sizeof(s_sta_config));
        s_wifi_disconnect_reason = 0;
        s_wifi_failure[0] = '\0';
        err = start_setup_portal();
    }
    memset(&empty, 0, sizeof(empty));
    if (err != ESP_OK) report(PPT_NETWORK_ERROR, err);
    return err;
}
