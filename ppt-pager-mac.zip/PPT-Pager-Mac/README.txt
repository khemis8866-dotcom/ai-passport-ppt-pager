PPT Pager Mac companion

Requires macOS and Python 3.9 or newer. No pip dependencies.

1. Put the Mac and AI Passport on the same local network. On first use, use an iPhone to join the PPTPager-xxxx hotspot shown on the device, then open http://192.168.4.1 and enter the venue's 2.4 GHz Wi-Fi credentials. LOOKING FOR MAC confirms success.
2. In Terminal, enter this folder and run:
   python3 ppt_pager_companion.py --code 123456
   Replace 123456 with the six digits after PAIR on the device.
3. Give Terminal Screen Recording and Accessibility permissions. Approve System Events automation if requested. Keep WPS or your slideshow focused.
4. UP: previous. DOWN: next. Short OK: volume up. Long OK: volume down.
5. Ctrl+C stops the companion. Restart it with the new code after a device restart. Double-press UP on the device only when you intend to clear its saved Wi-Fi configuration.

Documentation and current source:
https://github.com/khemis8866-dotcom/ai-passport-ppt-pager
