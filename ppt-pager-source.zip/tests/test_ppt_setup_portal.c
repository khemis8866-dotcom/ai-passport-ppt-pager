#include "ppt_setup_portal.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    ppt_setup_credentials_t credentials;
    const char office_form[] = "ssid=Office+Wi-Fi&password=correct-horse";
    assert(ppt_setup_parse_form(office_form, sizeof(office_form) - 1, &credentials));
    assert(strcmp(credentials.ssid, "Office Wi-Fi") == 0);
    assert(strcmp(credentials.password, "correct-horse") == 0);

    const char utf8_form[] = "ssid=%E6%BC%94%E7%A4%BA&password=";
    assert(ppt_setup_parse_form(utf8_form, sizeof(utf8_form) - 1, &credentials));
    assert(strcmp(credentials.ssid, "\xE6\xBC\x94\xE7\xA4\xBA") == 0);
    assert(credentials.password[0] == '\0');

    const char empty_ssid[] = "ssid=&password=12345678";
    const char short_password[] = "ssid=Office&password=short";
    const char invalid_escape[] = "ssid=Office&password=%QQ";
    const char duplicate_ssid[] = "ssid=One&ssid=Two&password=12345678";
    const char extra_field[] = "ssid=Office&password=12345678&extra=1";
    assert(!ppt_setup_parse_form(empty_ssid, sizeof(empty_ssid) - 1, &credentials));
    assert(!ppt_setup_parse_form(short_password, sizeof(short_password) - 1, &credentials));
    assert(!ppt_setup_parse_form(invalid_escape, sizeof(invalid_escape) - 1, &credentials));
    assert(!ppt_setup_parse_form(duplicate_ssid, sizeof(duplicate_ssid) - 1, &credentials));
    assert(!ppt_setup_parse_form(extra_field, sizeof(extra_field) - 1, &credentials));

    char escaped[193];
    const char hostile_ssid[] = "A\"<&'>";
    assert(ppt_setup_html_escape(hostile_ssid, strlen(hostile_ssid), escaped, sizeof(escaped)));
    assert(strcmp(escaped, "A&quot;&lt;&amp;&#39;&gt;") == 0);
    const char chinese_ssid[] = "\xE6\xBC\x94\xE7\xA4\xBA Wi-Fi";
    assert(ppt_setup_html_escape(chinese_ssid, strlen(chinese_ssid), escaped, sizeof(escaped)));
    assert(strcmp(escaped, chinese_ssid) == 0);
    char too_small[6];
    assert(!ppt_setup_html_escape("\"", 1, too_small, sizeof(too_small)));
    char exact[7];
    assert(ppt_setup_html_escape("\"", 1, exact, sizeof(exact)));
    assert(strcmp(exact, "&quot;") == 0);
    char largest_ssid[32];
    memset(largest_ssid, '"', sizeof(largest_ssid));
    assert(ppt_setup_html_escape(largest_ssid, sizeof(largest_ssid), escaped, sizeof(escaped)));
    assert(strlen(escaped) == 192);
    assert(!ppt_setup_html_escape("A\0B", 3, escaped, sizeof(escaped)));

    puts("PPT setup portal parser tests: PASS");
    return 0;
}
