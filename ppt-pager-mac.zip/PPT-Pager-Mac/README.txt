PPT 翻页笔 · 原生彩色 Mac 伴侣

本项目仅供个人学习研究，严禁商用。项目新增部分采用 PolyForm Noncommercial
1.0.0，适用范围见 LICENSE 与 NOTICE；上游 MIT 及既有授权保留。

需要 macOS、Python 3.9 或更新版本，无需安装额外 Python 包。
新版固件请求 240×135 RGB565 彩色画面；旧固件仍得到 128×72 黑白预览。
画面保持电脑屏幕比例，必要时留白。Mac 原生缩放保留抗锯齿细节；预览不是视频。
小屏无法清楚显示电脑上的所有小字号，演示时请使用全屏和较大的文字。

1. 下载并解压本文件夹。按 Command+空格搜索“终端”，运行 python3 --version；
   如未安装合适版本，从 https://www.python.org/downloads/macos/ 安装后重开终端。
2. Mac 与设备连接同一局域网。首次配网：iPhone 连接设备屏幕的热点，密码看
   “热点密码”；Safari 打开 http://192.168.4.1，选择现场 2.4 GHz Wi-Fi、填写
   密码并点 Connect PPT Pager。设备显示“等待电脑连接”后，手机可回连原网络。
3. 如果旧伴侣仍在运行，先在它的终端按 Control+C。新终端输入 cd 加一个空格，
   将这个 PPT-Pager-Mac 文件夹从访达拖进去，再回车。然后运行：
   python3 ppt_pager_companion.py --code 123456
   把 123456 换成设备当前的“配对码”。保留终端窗口运行。
4. 为“终端”允许屏幕录制、辅助功能，以及提示的 System Events 控制权限。
   如要求重开终端，重复第 3 步；设备显示“已连接电脑”后开始放映，保持窗口前台。
5. 上键上一页，下键下一页；确定键短按加音量、长按减音量。Control+C 停止伴侣。
   设备重启后先停止旧伴侣，再用新配对码重启，无需重新下载。配网失败可重连
   设备热点并在网页点 Choose Wi-Fi again；需要换网时双击上键清除旧网络并重新配网。

PPT Pager · Native-color Mac companion

For personal study and research only. Commercial use is strictly prohibited.
Project-specific contributions use PolyForm Noncommercial 1.0.0; see LICENSE
and NOTICE. Upstream MIT and previous grants remain in effect.

Requires macOS and Python 3.9 or newer; no additional Python packages.
New firmware requests 240×135 RGB565 color. Old firmware still receives the
128×72 monochrome preview. Native resizing preserves antialiasing and the Mac
screen's aspect ratio, adding margins if needed. This is a preview, not video;
use a full-screen presentation and larger text for this small display.

1. Extract this folder. Open Terminal using Command+Space and run
   python3 --version. If needed, install a compatible Python 3 from
   https://www.python.org/downloads/macos/ and reopen Terminal.
2. Keep the Mac and device on the same local network. For initial setup, join
   the device's hotspot on an iPhone using the password on its screen. Open
   http://192.168.4.1 in Safari, select the venue's 2.4 GHz Wi-Fi, enter the
   password and tap Connect PPT Pager. After the device waits for the Mac,
   your iPhone can return to its normal Wi-Fi.
3. Stop any older companion with Control+C. In a new Terminal, type cd plus
   one space, drag this PPT-Pager-Mac folder from Finder, and press Return.
   Run python3 ppt_pager_companion.py --code 123456 with the device's current
   six-digit pairing code in place of 123456. Keep Terminal running.
4. Grant Terminal Screen Recording, Accessibility and any requested System
   Events automation permission. If Terminal must reopen, repeat step 3.
   Wait for the device to indicate connection and keep your slideshow focused.
5. UP: previous; DOWN: next; short OK: volume up; long OK: volume down.
   Control+C stops the companion. After a device restart, stop the old process
   and rerun with the new code. No new download is needed. If Wi-Fi setup fails,
   rejoin its hotspot and use Choose Wi-Fi again. Double-press UP only to clear
   saved Wi-Fi and set up a different network.
