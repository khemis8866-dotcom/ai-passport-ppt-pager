#include "ppt_network.h"
#include "ppt_protocol.h"

#include "bsp_battery.h"
#include "bsp_button.h"
#include "bsp_display.h"
#include "bsp_i2c.h"
#include "bsp_pins.h"
#include "key_guard.h"

#include "esp_err.h"
#include "esp_log.h"
#include "esp_sleep.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lvgl.h"

#include <string.h>

static const char *TAG = "ppt_pager";

#define APP_EVENT_QUEUE_DEPTH 3
#define PREVIEW_BUFFER_BYTES (8 + PPT_PROTOCOL_PREVIEW_BYTES)
#define KEY_GUARD_MAX_US (10LL * 1000 * 1000)

typedef enum {
    APP_EVENT_KEY,
    APP_EVENT_NETWORK,
    APP_EVENT_PREVIEW,
} app_event_type_t;

typedef struct {
    app_event_type_t type;
    union {
        struct {
            bsp_btn_t button;
            bsp_btn_ev_t action;
        } key;
        ppt_network_status_t network;
        struct {
            uint32_t revision;
            uint8_t pixels[PPT_PROTOCOL_PREVIEW_BYTES];
        } preview;
    } data;
} app_event_t;

static QueueHandle_t s_events;
static TaskHandle_t s_app_task;
static lv_obj_t *s_screen;
static lv_obj_t *s_status;
static lv_obj_t *s_code;
static lv_obj_t *s_title;
static lv_obj_t *s_battery;
static lv_obj_t *s_preview;
static uint8_t s_preview_buffer[PREVIEW_BUFFER_BYTES];
static bool s_battery_ready;
static volatile bool s_input_ready;
static key_guard_t s_key_guard;

static lv_obj_t *label(lv_obj_t *parent, const char *text, const lv_font_t *font,
                       uint32_t color)
{
    lv_obj_t *object = lv_label_create(parent);
    lv_label_set_text(object, text);
    lv_obj_set_style_text_font(object, font, 0);
    lv_obj_set_style_text_color(object, lv_color_hex(color), 0);
    return object;
}

static void panel(lv_obj_t *object, int x, int y, int width, int height, uint32_t color)
{
    lv_obj_set_pos(object, x, y);
    lv_obj_set_size(object, width, height);
    lv_obj_remove_flag(object, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_radius(object, 12, 0);
    lv_obj_set_style_border_width(object, 1, 0);
    lv_obj_set_style_border_color(object, lv_color_hex(0x243247), 0);
    lv_obj_set_style_bg_color(object, lv_color_hex(color), 0);
    lv_obj_set_style_pad_all(object, 0, 0);
}

static const char *state_text(ppt_network_state_t state)
{
    switch (state) {
    case PPT_NETWORK_STARTING: return "STARTING RADIO";
    case PPT_NETWORK_PROVISIONING: return "IPHONE WI-FI SETUP";
    case PPT_NETWORK_CONNECTING: return "CONNECTING WI-FI";
    case PPT_NETWORK_DISCOVERING: return "LOOKING FOR MAC";
    case PPT_NETWORK_LINKED: return "CONNECTED";
    case PPT_NETWORK_ERROR: return "NETWORK ERROR";
    }
    return "WAITING";
}

static void refresh_battery(void)
{
    if (!s_battery_ready || s_battery == NULL) return;
    int percent = bsp_battery_soc();
    if (percent < 0) {
        lv_label_set_text(s_battery, "--%");
    } else {
        lv_label_set_text_fmt(s_battery, "%d%%", percent);
    }
}

static void ui_show_status(const ppt_network_status_t *status)
{
    lv_label_set_text(s_status, state_text(status->state));
    if (status->state == PPT_NETWORK_PROVISIONING && status->wifi_failure[0] != '\0') {
        lv_label_set_text(s_status, status->wifi_failure);
    }
    if (status->state == PPT_NETWORK_PROVISIONING && status->setup_ssid[0] != '\0') {
        lv_label_set_text_fmt(s_code, "AP %s", status->setup_password);
    } else {
        lv_label_set_text_fmt(s_code, "PAIR %s", status->pair_code);
    }
    if (status->title[0] != '\0') {
        lv_label_set_text(s_title, status->title);
    } else if (status->state == PPT_NETWORK_PROVISIONING) {
        lv_label_set_text_fmt(s_title, "JOIN %s", status->setup_ssid);
    } else {
        lv_label_set_text(s_title, "LIVE SCREEN PREVIEW");
    }
}

static void ui_show_preview(const uint8_t *pixels)
{
    memcpy(s_preview_buffer + 8, pixels, PPT_PROTOCOL_PREVIEW_BYTES);
    lv_obj_invalidate(s_preview);
}

static void ui_build(void)
{
    s_screen = lv_obj_create(NULL);
    lv_obj_remove_flag(s_screen, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0B1220), 0);
    lv_obj_set_style_bg_opa(s_screen, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_screen, 0, 0);
    lv_obj_set_style_pad_all(s_screen, 0, 0);

    lv_obj_t *top = lv_obj_create(s_screen);
    panel(top, 9, 8, 222, 34, 0x16243A);
    lv_obj_t *brand = label(top, "PPT PAGER", &lv_font_montserrat_20, 0xEEF5FF);
    lv_obj_align(brand, LV_ALIGN_LEFT_MID, 10, 0);
    s_battery = label(top, "--%", &lv_font_montserrat_14, 0x9BC7FF);
    lv_obj_align(s_battery, LV_ALIGN_RIGHT_MID, -9, 0);

    lv_obj_t *frame = lv_obj_create(s_screen);
    panel(frame, 16, 55, 208, 118, 0xDCE8F3);
    s_preview = lv_canvas_create(frame);
    lv_canvas_set_buffer(s_preview, s_preview_buffer, PPT_PROTOCOL_PREVIEW_WIDTH,
                         PPT_PROTOCOL_PREVIEW_HEIGHT, LV_COLOR_FORMAT_I1);
    lv_canvas_set_palette(s_preview, 0, lv_color32_make(0xF8, 0xFB, 0xFF, LV_OPA_COVER));
    lv_canvas_set_palette(s_preview, 1, lv_color32_make(0x17, 0x20, 0x33, LV_OPA_COVER));
    lv_obj_set_pos(s_preview, 40, 22);
    lv_obj_set_style_border_width(s_preview, 1, 0);
    lv_obj_set_style_border_color(s_preview, lv_color_hex(0x64758A), 0);

    s_title = label(s_screen, "LIVE SCREEN PREVIEW", &lv_font_montserrat_14, 0xDCE8F3);
    lv_obj_set_width(s_title, 210);
    lv_obj_set_style_text_align(s_title, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(s_title, LV_ALIGN_TOP_MID, 0, 184);

    lv_obj_t *network = lv_obj_create(s_screen);
    panel(network, 16, 213, 208, 61, 0x16243A);
    s_status = label(network, "STARTING RADIO", &lv_font_montserrat_14, 0x9BC7FF);
    lv_obj_align(s_status, LV_ALIGN_TOP_MID, 0, 8);
    s_code = label(network, "PAIR ------", &lv_font_montserrat_14, 0xF4D25B);
    lv_obj_align(s_code, LV_ALIGN_BOTTOM_MID, 0, -8);

    lv_obj_t *hint = label(s_screen, "UP PREV   DOWN NEXT   OK +VOL   HOLD OK -VOL",
                           &lv_font_montserrat_14, 0x8392A5);
    lv_obj_set_width(hint, 222);
    lv_obj_set_style_text_align(hint, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -18);

    lv_screen_load(s_screen);
    refresh_battery();
}

static void on_network_status(const ppt_network_status_t *status, void *context)
{
    (void)context;
    if (s_events == NULL || status == NULL) return;
    app_event_t event = {
        .type = APP_EVENT_NETWORK,
        .data.network = *status,
    };
    (void)xQueueSend(s_events, &event, 0);
}

static void on_network_preview(uint32_t revision, const uint8_t *pixels, void *context)
{
    (void)context;
    if (s_events == NULL || pixels == NULL) return;
    app_event_t event = {
        .type = APP_EVENT_PREVIEW,
        .data.preview.revision = revision,
    };
    memcpy(event.data.preview.pixels, pixels, sizeof(event.data.preview.pixels));
    (void)xQueueSend(s_events, &event, 0);
}

static void on_key(bsp_btn_t button, bsp_btn_ev_t action, void *context)
{
    (void)context;
    const bool was_armed = s_key_guard.armed;
    if (key_guard_consume(&s_key_guard, action == BSP_BTN_RELEASE, esp_timer_get_time())) {
        if (was_armed && !s_key_guard.armed) {
            ESP_LOGI(TAG, "wake key released; input enabled");
        }
        return;
    }
    if (!s_input_ready || s_events == NULL ||
        (action != BSP_BTN_CLICK && action != BSP_BTN_LONG && action != BSP_BTN_DOUBLE)) {
        return;
    }
    app_event_t event = {
        .type = APP_EVENT_KEY,
        .data.key = { .button = button, .action = action },
    };
    (void)xQueueSend(s_events, &event, 0);
}

static void handle_key(const app_event_t *event)
{
    bsp_btn_t button = event->data.key.button;
    bsp_btn_ev_t action = event->data.key.action;
    if (button == BSP_BTN_UP && action == BSP_BTN_DOUBLE) {
        (void)ppt_network_clear_wifi();
    } else if (button == BSP_BTN_UP && action == BSP_BTN_CLICK) {
        (void)ppt_network_send_command(PPT_PROTOCOL_COMMAND_PREVIOUS);
    } else if (button == BSP_BTN_DOWN && action == BSP_BTN_CLICK) {
        (void)ppt_network_send_command(PPT_PROTOCOL_COMMAND_NEXT);
    } else if (button == BSP_BTN_OK && action == BSP_BTN_CLICK) {
        (void)ppt_network_send_command(PPT_PROTOCOL_COMMAND_VOLUME_UP);
    } else if (button == BSP_BTN_OK && action == BSP_BTN_LONG) {
        (void)ppt_network_send_command(PPT_PROTOCOL_COMMAND_VOLUME_DOWN);
    }
}

static void app_task(void *arg)
{
    (void)arg;
    app_event_t event;
    TickType_t last_battery = 0;
    for (;;) {
        if (xQueueReceive(s_events, &event, pdMS_TO_TICKS(250)) == pdTRUE) {
            if (event.type == APP_EVENT_KEY) {
                /* Network operations must not run while the LVGL mutex is held. */
                handle_key(&event);
            } else if (bsp_lvgl_lock(250)) {
                if (event.type == APP_EVENT_NETWORK) {
                    ui_show_status(&event.data.network);
                } else if (event.type == APP_EVENT_PREVIEW) {
                    ui_show_preview(event.data.preview.pixels);
                }
                bsp_lvgl_unlock();
            }
        }
        TickType_t now = xTaskGetTickCount();
        if (now - last_battery >= pdMS_TO_TICKS(10000) && bsp_lvgl_lock(100)) {
            refresh_battery();
            last_battery = now;
            bsp_lvgl_unlock();
        }
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "PPT Pager starting");
    const uint32_t wake_causes = esp_sleep_get_wakeup_causes();
    if (wake_causes & (1u << ESP_SLEEP_WAKEUP_GPIO)) {
        key_guard_arm(&s_key_guard, esp_timer_get_time(), KEY_GUARD_MAX_US);
        ESP_LOGI(TAG, "GPIO wake: waiting for wake key release");
    }
    (void)bsp_i2c_init();
    if (bsp_display_init() != ESP_OK || bsp_lvgl_init() == NULL) {
        ESP_LOGE(TAG, "display or LVGL init failed");
        return;
    }
    bsp_display_backlight(100);
    s_battery_ready = bsp_battery_init() == ESP_OK;
    s_events = xQueueCreate(APP_EVENT_QUEUE_DEPTH, sizeof(app_event_t));
    if (s_events == NULL) {
        ESP_LOGE(TAG, "event queue allocation failed");
        return;
    }
    if (!bsp_lvgl_lock(1000)) {
        ESP_LOGE(TAG, "LVGL lock unavailable");
        return;
    }
    ui_build();
    bsp_lvgl_unlock();
    if (xTaskCreate(app_task, "ppt_app", 4096, NULL, 5, &s_app_task) != pdPASS) {
        ESP_LOGE(TAG, "app task init failed");
        return;
    }
    if (bsp_button_init(on_key, NULL) != ESP_OK) {
        ESP_LOGE(TAG, "button init failed");
        vTaskDelete(s_app_task);
        s_app_task = NULL;
        return;
    }
    if (s_key_guard.armed) {
        const bool released = bsp_button_read_mv() >= BSP_BTN_MV_RELEASED_MIN;
        key_guard_sync_released(&s_key_guard, released);
    }
    s_input_ready = true;
    ppt_network_callbacks_t callbacks = {
        .status = on_network_status,
        .preview = on_network_preview,
        .context = NULL,
    };
    esp_err_t err = ppt_network_start(&callbacks);
    if (err != ESP_OK) ESP_LOGE(TAG, "network start failed: %s", esp_err_to_name(err));
}
