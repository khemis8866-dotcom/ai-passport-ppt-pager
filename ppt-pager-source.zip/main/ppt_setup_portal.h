// Parsing for the local iPhone Wi-Fi setup form.  This file is deliberately
// independent of ESP-IDF so malformed form bodies can be covered by host tests.
#pragma once

#include <stdbool.h>
#include <stddef.h>

#define PPT_SETUP_SSID_MAX 32
#define PPT_SETUP_PASSWORD_MAX 64

typedef struct {
    char ssid[PPT_SETUP_SSID_MAX + 1];
    char password[PPT_SETUP_PASSWORD_MAX + 1];
} ppt_setup_credentials_t;

// Parses application/x-www-form-urlencoded fields named ssid and password.
// An empty password is valid for an open network; other passwords must be a
// WPA passphrase (8-63 bytes) or a 64-character hexadecimal PSK.
bool ppt_setup_parse_form(const char *body, size_t length, ppt_setup_credentials_t *credentials);

// Escapes an SSID for HTML text or a double-quoted attribute, preserving UTF-8.
// The destination must accommodate the complete result including its NUL.
bool ppt_setup_html_escape(const char *input, size_t length, char *output, size_t output_size);
