#include "ppt_protocol.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    char message[64];
    assert(ppt_protocol_pair_code_valid("120045"));
    assert(!ppt_protocol_pair_code_valid("12004"));
    assert(!ppt_protocol_pair_code_valid("12004x"));
    assert(ppt_protocol_format_discovery("120045", message, sizeof(message)));
    assert(strcmp(message, "FPP/1 DISCOVER 120045\n") == 0);

    ppt_protocol_host_t host;
    const char host_message[] = "FPP/1 HOST 120045 192.168.1.3 37987\n";
    assert(ppt_protocol_parse_host(host_message, sizeof(host_message) - 1,
                                   "120045", &host));
    assert(strcmp(host.host, "192.168.1.3") == 0 && host.port == 37987);
    assert(!ppt_protocol_parse_host("FPP/1 HOST 120045 999.168.1.3 37987\n", 43,
                                    "120045", &host));

    ppt_protocol_state_t state;
    const char state_body[] = "FPPSTATE/1\npreview:7\ntitle:LIVE SCREEN\n";
    assert(ppt_protocol_parse_state(state_body, sizeof(state_body) - 1, &state));
    assert(state.preview_revision == 7 && strcmp(state.title, "LIVE SCREEN") == 0);
    assert(!ppt_protocol_parse_state("FPPSTATE/2\npreview:7\n", 21, &state));

    uint8_t preview[10 + PPT_PROTOCOL_PREVIEW_BYTES] = "P4\n128 72\n";
    const uint8_t *pixels = NULL;
    size_t bytes = 0;
    assert(ppt_protocol_pbm_payload(preview, sizeof(preview), &pixels, &bytes));
    assert(bytes == PPT_PROTOCOL_PREVIEW_BYTES && pixels == preview + 10);
    puts("PPT Pager protocol tests: PASS");
    return 0;
}
