// Wi-Fi, local web provisioning and companion transport for PPT Pager.
#pragma once

#include "esp_err.h"
#include "ppt_protocol.h"

#include <stdbool.h>
#include <stdint.h>

#define PPT_NETWORK_SETUP_SSID_MAX 32
#define PPT_NETWORK_SETUP_PASSWORD_MAX 16

typedef enum {
    PPT_NETWORK_STARTING,
    PPT_NETWORK_PROVISIONING,
    PPT_NETWORK_CONNECTING,
    PPT_NETWORK_DISCOVERING,
    PPT_NETWORK_LINKED,
    PPT_NETWORK_ERROR,
} ppt_network_state_t;

typedef struct {
    ppt_network_state_t state;
    esp_err_t error;
    char pair_code[PPT_PROTOCOL_PAIR_CODE_LENGTH + 1];
    char setup_ssid[PPT_NETWORK_SETUP_SSID_MAX + 1];
    char setup_password[PPT_NETWORK_SETUP_PASSWORD_MAX + 1];
    char wifi_failure[32];
    char ip[16];
    char title[PPT_PROTOCOL_TITLE_MAX];
} ppt_network_status_t;

typedef void (*ppt_network_status_cb_t)(const ppt_network_status_t *status, void *context);
typedef void (*ppt_network_preview_cb_t)(uint32_t revision, const uint8_t *pixels,
                                         void *context);

typedef struct {
    ppt_network_status_cb_t status;
    ppt_network_preview_cb_t preview;
    void *context;
} ppt_network_callbacks_t;

esp_err_t ppt_network_start(const ppt_network_callbacks_t *callbacks);
esp_err_t ppt_network_send_command(ppt_protocol_command_t command);
esp_err_t ppt_network_clear_wifi(void);
