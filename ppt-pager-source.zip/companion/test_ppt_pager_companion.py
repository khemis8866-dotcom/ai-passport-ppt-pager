import importlib.util
import struct
import sys
import unittest
from unittest import mock
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("ppt_pager_companion", ROOT / "ppt_pager_companion.py")
assert SPEC and SPEC.loader
COMPANION = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = COMPANION
SPEC.loader.exec_module(COMPANION)


def bmp_24(width: int, height: int, color: tuple[int, int, int]) -> bytes:
    stride = (width * 3 + 3) & ~3
    pixels = bytearray(stride * height)
    blue, green, red = color
    for row in range(height):
        for column in range(width):
            offset = row * stride + column * 3
            pixels[offset:offset + 3] = bytes((blue, green, red))
    offset = 54
    file_size = offset + len(pixels)
    header = struct.pack("<2sIHHI", b"BM", file_size, 0, 0, offset)
    dib = struct.pack("<IiiHHIIiiII", 40, width, height, 1, 24, 0, len(pixels),
                      0, 0, 0, 0)
    return header + dib + pixels


def bmp_32_bitfields() -> bytes:
    # Match the real Mac capture: V5 header, top-down, BI_BITFIELDS, BGRA.
    pixels = b"\x00\x00\x00\xff\xff\xff\xff\xff"
    offset = 14 + 124
    header = struct.pack("<2sIHHI", b"BM", offset + len(pixels), 0, 0, offset)
    dib = bytearray(124)
    struct.pack_into("<IiiHHII", dib, 0, 124, 1, -2, 1, 32, 3, len(pixels))
    struct.pack_into("<IIII", dib, 40, 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
    return header + dib + pixels


class CompanionTest(unittest.TestCase):
    def test_pair_code_and_discovery(self) -> None:
        self.assertTrue(COMPANION.valid_pair_code("012345"))
        self.assertFalse(COMPANION.valid_pair_code("12345x"))
        self.assertEqual(COMPANION.parse_discovery(b"FPP/1 DISCOVER 012345\n"), "012345")
        self.assertIsNone(COMPANION.parse_discovery(b"FPP/1 DISCOVER nope\n"))

    def test_black_bmp_becomes_black_pbm(self) -> None:
        result = COMPANION.bitmap_from_bmp(bmp_24(2, 2, (0, 0, 0)))
        self.assertEqual(len(result), COMPANION.PREVIEW_BYTES)
        self.assertTrue(all(value == 0xFF for value in result))

    def test_discovery_advertises_the_mac_route_not_the_device_address(self) -> None:
        peer = ("192.0.2.42", 49152)
        with mock.patch.object(COMPANION.socket, "socket") as socket_factory:
            route = socket_factory.return_value.__enter__.return_value
            route.getsockname.return_value = ("192.0.2.10", 50000)
            response = COMPANION.discovery_response("012345", peer, 37987)
            route.connect.assert_called_once_with(peer)
            route.send.assert_not_called()
            route.sendto.assert_not_called()
        self.assertEqual(response, b"FPP/1 HOST 012345 192.0.2.10 37987\n")

    def test_white_bmp_becomes_white_pbm(self) -> None:
        result = COMPANION.bitmap_from_bmp(bmp_24(2, 2, (255, 255, 255)))
        self.assertEqual(result, bytes(COMPANION.PREVIEW_BYTES))

    def test_macos_bitfields_preserve_top_down_rows(self) -> None:
        result = COMPANION.bitmap_from_bmp(bmp_32_bitfields(), width=8, height=2)
        self.assertEqual(result, b"\xff\x00")

    def test_unknown_bitfield_masks_are_rejected(self) -> None:
        image = bytearray(bmp_32_bitfields())
        struct.pack_into("<I", image, 54, 0x000000FF)
        with self.assertRaisesRegex(ValueError, "channel masks"):
            COMPANION.bitmap_from_bmp(bytes(image))

    def test_capture_recovers_after_a_bad_bitmap(self) -> None:
        pager = COMPANION.PagerState(pair_code="012345")
        preview = bytes([0xFF]) * COMPANION.PREVIEW_BYTES
        with mock.patch.object(COMPANION, "capture_macos_preview",
                               side_effect=[ValueError("unsupported format"), preview]):
            pager.refresh_preview()
            self.assertEqual(pager.title, "SCREEN PREVIEW ERROR")
            self.assertEqual(pager.last_error, "unsupported format")
            pager.refresh_preview()
        self.assertEqual(pager.title, "LIVE SCREEN PREVIEW")
        self.assertEqual(pager.last_error, "")
        self.assertEqual(pager.preview_revision, 1)

    def test_control_timeout_becomes_a_reportable_error(self) -> None:
        with mock.patch.object(COMPANION.subprocess, "run", side_effect=
                               COMPANION.subprocess.TimeoutExpired("osascript", 5)):
            with self.assertRaisesRegex(RuntimeError, "Accessibility and Automation"):
                COMPANION.run_osascript("return true")

    def test_failed_control_does_not_break_state_requests(self) -> None:
        pager = COMPANION.PagerState(pair_code="012345")
        handler = object.__new__(COMPANION.CompanionHandler)
        handler.server = mock.Mock(pager=pager)
        handler.path = "/v1/control?code=012345&command=next"
        handler.respond = mock.Mock()
        with mock.patch.object(pager, "control", side_effect=RuntimeError("permission needed")), \
                mock.patch("builtins.print"):
            handler.do_GET()
        handler.respond.assert_called_once_with(409, "text/plain", b"permission needed\n")
        handler.respond.reset_mock()
        handler.path = "/v1/state?code=012345"
        handler.do_GET()
        self.assertEqual(handler.respond.call_args.args[0], 200)
        self.assertIn(b"FPPSTATE/1", handler.respond.call_args.args[2])


if __name__ == "__main__":
    unittest.main()
