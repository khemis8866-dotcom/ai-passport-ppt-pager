// Local-network protocol shared by the PPT Pager firmware and its companion.
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define PPT_PROTOCOL_PAIR_CODE_LENGTH 6
#define PPT_PROTOCOL_HOST_MAX 16
#define PPT_PROTOCOL_TITLE_MAX 48
#define PPT_PROTOCOL_PREVIEW_WIDTH 128
#define PPT_PROTOCOL_PREVIEW_HEIGHT 72
#define PPT_PROTOCOL_PREVIEW_BYTES \
    ((PPT_PROTOCOL_PREVIEW_WIDTH * PPT_PROTOCOL_PREVIEW_HEIGHT) / 8)

typedef enum {
    PPT_PROTOCOL_COMMAND_PREVIOUS,
    PPT_PROTOCOL_COMMAND_NEXT,
    PPT_PROTOCOL_COMMAND_VOLUME_UP,
    PPT_PROTOCOL_COMMAND_VOLUME_DOWN,
} ppt_protocol_command_t;

typedef struct {
    char host[PPT_PROTOCOL_HOST_MAX];
    uint16_t port;
} ppt_protocol_host_t;

typedef struct {
    uint32_t preview_revision;
    char title[PPT_PROTOCOL_TITLE_MAX];
} ppt_protocol_state_t;

bool ppt_protocol_pair_code_valid(const char *code);
bool ppt_protocol_format_discovery(const char *code, char *out, size_t out_size);
bool ppt_protocol_parse_host(const char *message, size_t length, const char *code,
                             ppt_protocol_host_t *out);
bool ppt_protocol_parse_state(const char *body, size_t length, ppt_protocol_state_t *out);
const char *ppt_protocol_command_name(ppt_protocol_command_t command);
bool ppt_protocol_pbm_payload(const uint8_t *body, size_t length,
                              const uint8_t **pixels, size_t *pixel_length);
